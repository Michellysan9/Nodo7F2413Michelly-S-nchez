import java.util.Scanner;

public class Cajero_Automatico {
    static final int NUMERO_CUENTA = 123456;
    static final int PIN_CORRECTO = 1234;
    static double saldo = 1000.00; 

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean sesionIniciada = false;

        while (!sesionIniciada) {
            System.out.print("Ingrese el número de cuenta: ");
            int numeroCuenta = scanner.nextInt();
            System.out.print("Ingrese el PIN: ");
            int pin = scanner.nextInt();

            if (numeroCuenta == NUMERO_CUENTA && pin == PIN_CORRECTO) {
                sesionIniciada = true;
                System.out.println("Inicio de sesión exitoso.");
            } else {
                System.out.println("Número de cuenta o PIN incorrecto. Inténtelo de nuevo.");
            }
        }

        boolean continuar = true;
        while (continuar) {
            System.out.println("\nMenú:");
            System.out.println("1. Consultar saldo");
            System.out.println("2. Retirar dinero");
            System.out.println("3. Depositar dinero");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    consultarSaldo();
                    break;
                case 2:
                    retirarDinero(scanner);
                    break;
                case 3:
                    depositarDinero(scanner);
                    break;
                case 4:
                    continuar = false;
                    System.out.println("Gracias por usar el cajero automático.");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }
        
        scanner.close();
    }

    public static void consultarSaldo() {
        System.out.println("Saldo actual: $" + saldo);
    }

    public static void retirarDinero(Scanner scanner) {
        System.out.print("Ingrese el monto a retirar: $");
        double monto = scanner.nextDouble();
        if (monto > 0 && monto <= saldo) {
            saldo -= monto;
            System.out.println("Retiro exitoso. Saldo restante: $" + saldo);
        } else {
            System.out.println("Monto inválido o saldo insuficiente.");
        }
    }

    public static void depositarDinero(Scanner scanner) {
        System.out.print("Ingrese el monto a depositar: $");
        double monto = scanner.nextDouble();
        if (monto > 0) {
            saldo += monto;
            System.out.println("Depósito exitoso. Saldo actual: $" + saldo);
        } else {
            System.out.println("Monto inválido.");
        }
    }
}

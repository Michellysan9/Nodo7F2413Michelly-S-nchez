import java.util.Scanner;

public class HabitosDiarion {
	
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        String[] habits = new String[3];  
	        boolean[] progress = new boolean[3];  
	        int habitCount = 0;
	        
	        System.out.println("Seguimiento de Hábitos");
	     
	        System.out.println("Ingresa tus hábitos diarios:");
	        for (int i = 0; i < habits.length; i++) {
	            System.out.print("Hábito " + (i + 1) + ": ");
	            habits[i] = scanner.nextLine();
	            habitCount++;
	            if (i < habits.length - 1) {
	                System.out.print("¿Quieres agregar otro hábito? (sí/no): ");
	                String respuesta = scanner.nextLine();
	                if (respuesta.equalsIgnoreCase("no")) {
	                    break;
	                }
	            }
	        }
	        
	        System.out.println("\nRegistrar el progreso de hoy:");
	        for (int i = 0; i < habitCount; i++) {
	            System.out.print("¿Cumpliste con el hábito '" + habits[i] + "' hoy? (sí/no): ");
	            String respuesta = scanner.nextLine();
	            if (respuesta.equalsIgnoreCase("sí")) {
	                progress[i] = true;
	            } else {
	                progress[i] = false;
	            }
	        }
	        
	        System.out.println("\nResumen de tu progreso hoy:");
	        for (int i = 0; i < habitCount; i++) {
	            System.out.println(habits[i] + ": " + (progress[i] ? "Cumplido" : "No cumplido"));
	        }

	        scanner.close();
	    }


}

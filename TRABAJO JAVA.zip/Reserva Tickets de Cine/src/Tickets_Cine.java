import java.util.Scanner;

public class Tickets_Cine {
	  
    static String[] peliculas = {"1. Blade", "2. Toy Story", "3. El aro"};
    
    
    static int[][] asientos = new int[5][5]; 

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continuar = true;
        
        while (continuar) {
            System.out.println("Bienvenido al sistema de reserva de entradas de cine.");
            mostrarPeliculas();
            System.out.print("Seleccione una película (ingrese el número): ");
            int peliculaSeleccionada = scanner.nextInt();

            if (peliculaSeleccionada < 1 || peliculaSeleccionada > peliculas.length) {
                System.out.println("Película no válida. Intente de nuevo.");
                continue;
            }

            System.out.println("Ha seleccionado: " + peliculas[peliculaSeleccionada - 1]);
            mostrarAsientos();

            System.out.print("Ingrese la fila (1-5): ");
            int fila = scanner.nextInt();
            System.out.print("Ingrese el número de asiento (1-5): ");
            int asiento = scanner.nextInt();

            if (fila < 1 || fila > 5 || asiento < 1 || asiento > 5 || asientos[fila - 1][asiento - 1] == 1) {
                System.out.println("Asiento no disponible o fuera de rango. Intente de nuevo.");
                continue;
            }

            asientos[fila - 1][asiento - 1] = 1; // Reservar asiento
            System.out.println("Asiento reservado exitosamente.");

            simularPago();

            System.out.print("¿Desea realizar otra reserva? (S/N): ");
            continuar = scanner.next().equalsIgnoreCase("S");
        }

        System.out.println("Gracias por utilizar el sistema de reservas. ¡Disfrute la película!");
        scanner.close();
    }

    public static void mostrarPeliculas() {
        for (String pelicula : peliculas) {
            System.out.println(pelicula);
        }
    }

   
    public static void mostrarAsientos() {
        System.out.println("Estado de los asientos (0 = libre, 1 = ocupado):");
        for (int i = 0; i < asientos.length; i++) {
            for (int j = 0; j < asientos[i].length; j++) {
                System.out.print(asientos[i][j] + " ");
            }
            System.out.println();
        }
    }

    
    public static void simularPago() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el monto a pagar: ");
        double pago = scanner.nextDouble();
        System.out.println("Procesando pago de $" + pago + "...");
        System.out.println("Pago realizado con éxito. ¡Gracias!");
    }
}

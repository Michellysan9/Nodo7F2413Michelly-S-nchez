import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class OfertaEmpleo {
    String titulo;
    String industria;
    String ubicacion;
    String tipoContrato;

    public OfertaEmpleo(String titulo, String industria, String ubicacion, String tipoContrato) {
        this.titulo = titulo;
        this.industria = industria;
        this.ubicacion = ubicacion;
        this.tipoContrato = tipoContrato;
    }

    @Override
    public String toString() {
        return "Título: " + titulo + ", Industria: " + industria + ", Ubicación: " + ubicacion + ", Tipo de Contrato: " + tipoContrato;
    }
}

class Aplicacion {
    String nombreCandidato;
    String resumen;

    public Aplicacion(String nombreCandidato, String resumen) {
        this.nombreCandidato = nombreCandidato;
        this.resumen = resumen;
    }

    @Override
    public String toString() {
        return "Candidato: " + nombreCandidato + ", Resumen: " + resumen;
    }
}

public class BolsaDeTrabajo {
    static List<OfertaEmpleo> ofertas = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        boolean continuar = true;

        while (continuar) {
            System.out.println("Simulador de Bolsa de Trabajo");
            System.out.println("1. Registrar oferta de empleo");
            System.out.println("2. Buscar ofertas de empleo");
            System.out.println("3. Aplicar a una oferta");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    registrarOferta();
                    break;
                case 2:
                    buscarOfertas();
                    break;
                case 3:
                    aplicarOferta();
                    break;
                case 4:
                    continuar = false;
                    System.out.println("Gracias por usar la bolsa de trabajo.");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        }

        scanner.close();
    }

    public static void registrarOferta() {
        System.out.print("Ingrese el título de la oferta: ");
        String titulo = scanner.nextLine();
        System.out.print("Ingrese la industria: ");
        String industria = scanner.nextLine();
        System.out.print("Ingrese la ubicación: ");
        String ubicacion = scanner.nextLine();
        System.out.print("Ingrese el tipo de contrato (Temporal/Indefinido): ");
        String tipoContrato = scanner.nextLine();

        OfertaEmpleo nuevaOferta = new OfertaEmpleo(titulo, industria, ubicacion, tipoContrato);
        ofertas.add(nuevaOferta);
        System.out.println("Oferta registrada exitosamente.");
    }

    public static void buscarOfertas() {
        System.out.println("Ofertas disponibles:");
        if (ofertas.isEmpty()) {
            System.out.println("No hay ofertas disponibles.");
        } else {
            for (int i = 0; i < ofertas.size(); i++) {
                System.out.println((i + 1) + ". " + ofertas.get(i));
            }
        }
    }

    public static void aplicarOferta() {
        System.out.print("Ingrese el número de la oferta a la que desea aplicar: ");
        int numOferta = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        if (numOferta < 1 || numOferta > ofertas.size()) {
            System.out.println("Número de oferta inválido.");
            return;
        }

        System.out.print("Ingrese su nombre: ");
        String nombreCandidato = scanner.nextLine();
        System.out.print("Ingrese su resumen de calificaciones y experiencia: ");
        String resumen = scanner.nextLine();

        Aplicacion nuevaAplicacion = new Aplicacion(nombreCandidato, resumen);
        System.out.println("Aplicación enviada con éxito a la oferta: " + ofertas.get(numOferta - 1));
        System.out.println("Resumen enviado: " + nuevaAplicacion);
    }
}

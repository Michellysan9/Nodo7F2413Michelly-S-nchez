export interface Book {
    name: string,
    favorite:boolean,
    category:string,
    url:string,
    imgUrl:string,
    saved:boolean,
    hasAudio: boolean,
    audioLink: string
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-allies-section',
  standalone: true,
  imports: [],
  templateUrl: './allies-section.component.html',
  styleUrl: './allies-section.component.css'
})
export class AlliesSectionComponent {

}
